import acm.graphics.GCompound;
import acm.graphics.GRect;
import acm.graphics.GOval;

import java.awt.*;

public class GDice extends GCompound {
    private int number;
    private int size;
    private Color cc;
    public Color ccc;
    public GDice(int diceNumber, int size, Color c){
        this.size=size;
        cc = c;
        ccc = new Color(255-cc.getRed(),255-cc.getGreen(),255-cc.getBlue());
        number = diceNumber;
        makeDice(size,number,c);
    }
    public GDice(int size){
        this(randomInt(1,6),size, Color.white);
    }
    public GDice(int size, Color c){
        this(randomInt(1,6),size, c);
    }
    private static int randomInt(int from, int to){
        return (int)Math.floor((Math.random()*(to-from+1))+from);
    }
    private void makeDice(int size, int diceNumber,Color c){
        GRect g = new GRect(size,size);
        add(g,0,0);
        g.setFilled(true);
        g.setFillColor(c);
        if(diceNumber%2==0){
            configureDice(diceNumber/2,size);
        }
        else{
            configureDice((diceNumber-1)/2,size);
            GOval o = new GOval(size/6,size/6);
            add(o,size/2-(o.getWidth()/2),size/2-(o.getHeight()/2));
            o.setFilled(true);
            o.setFillColor(ccc);
        }
    }
    private void configureDice(int sides, int size){
        if(sides == 0){
            //do nothing
        }
        else if (sides == 1){
            for (int i = 0; i < 2; i++) {
                for (int j = 0; j < 2; j++) {
                    if(i+j==1){
                        GOval o = new GOval(size/6,size/6);
                        add(o,(((i*2)+1)*size/4)-(o.getWidth()/2),(((j*2)+1)*size/4)-(o.getHeight()/2));
                        o.setFilled(true);
                        o.setFillColor(ccc);
                    }
                }
            }
        }
        else if (sides == 2){
            for (int i = 0; i < 2; i++) {
                for (int j = 0; j < 2; j++) {
                    GOval o = new GOval(size/6,size/6);
                    add(o,(((i*2)+1)*size/4)-(o.getWidth()/2),(((j*2)+1)*size/4)-(o.getHeight()/2));
                    o.setFilled(true);
                    o.setFillColor(ccc);
                }
            }
        }
        else{
            for (int i = 0; i < 2; i++) {
                for (int j = 0; j < 3; j++) {
                    GOval o = new GOval(size/6,size/6);
                    add(o,(((i*2)+1)*size/4)-(o.getWidth()/2),((j+1)*size/4)-(o.getHeight()/2));
                    o.setFilled(true);
                    o.setFillColor(ccc);
                }
            }
        }
    }
    public int rollDice(){
        for (int i = 0; i < 10; i++) {
            removeAll();
            number = randomInt(1,6);
            makeDice(size,number,cc);
            pause(100);
        }
        for (int i = 2; i < 11; i++) {
            removeAll();
            number = randomInt(1,6);
            makeDice(size,number,cc);
            pause(i*50);
        }
        return number;
    }

}
