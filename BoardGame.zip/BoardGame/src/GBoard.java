import acm.graphics.GCompound;
import acm.graphics.GPoint;
import acm.graphics.GRect;

import java.awt.*;
import java.util.ArrayList;

public class GBoard extends GCompound {
    public int size;
    public int tileSize;
    private ArrayList<Integer> t = new ArrayList<>();
    public GBoard(int size, int tileSize){
        this.size = size;
        this.tileSize = tileSize;
        t.add(0);
        for (int i = 1; i < (size*4)-4; i++) {
            t.add(GenerateTile());
        }
        t.set(randomInt(0,t.size()),12);
        t.set(randomInt(0,t.size()),12);
        for (int i = 0; i < t.size(); i++) {
            GRect G = new GRect(tileSize,tileSize);
            G.setFilled(true);
            G.setFillColor(ColorNumber(t.get(i)));
            G.setColor(OutlineColor(t.get(i)));
            add(G,LocatePoint(i));
        }
    }
    public int GenerateTile(){
        int r = randomInt(0,999);
        if(r < 400){
           return 1;
        }
        else if (r<500){
            return 2;
        }
        else if (r<600){
            return 3;
        }
        else if (r<675){
            return 4;
        }
        else if (r<750){
            return 5;
        }
        else if (r < 775){
            return 6;
        }
        else if (r < 800){
            return 7;
        }
        else if (r < 875){
            return 8;
        }
        else if (r<950){
            return 9;
        }
        else if (r<975){
            return 10;
        }
        else{
            return 11;
        }
    }
    private Color ColorNumber(int i){
        if (i == 1){
            return new Color(250,250,250);
        }
        else if (i == 2){
            return new Color(0,250,250);
        }
        else if (i == 3){
            return new Color(250,125,250);
        }
        else if (i == 4){
            return new Color(250,125,0);
        }
        else if (i == 5){
            return new Color(250,250,0);
        }
        else if (i == 6){
            return new Color(0,0,250);
        }
        else if (i == 7){
            return new Color(0,125,250);
        }
        else if (i == 8){
            return new Color(250,0,0);
        }
        else if (i == 9){
            return new Color(0,125,0);
        }
        else if (i == 10){
            return new Color(125,125,125);
        }
        else if (i == 11){
            return new Color(125,0,250);
        }
        else if (i == 12){
            return new Color(250,125,125);
        }
        return new Color(0,0,0);
    }
    private Color OutlineColor(int i){
        if (i % 2 == 0 && i!=0){
          return Color.red;
        }
        else if (i > 1){
            return Color.green;
        }
        return Color.black;
    }
    public GPoint LocatePoint(int i){
        GPoint g = new GPoint();
        if (i+1<=size){
            g.setLocation(tileSize*i,0);
        }
        else if (i+2<=size*2){
            g.setLocation((size-1)*tileSize,tileSize*(i-(size-1)));
        }
        else if (i+3<=size*3){
            g.setLocation(((size-1)*tileSize)-tileSize*(i-((size-1)*2)),(size-1)*tileSize);
        }
        else{
            g.setLocation(0,((size-1)*tileSize)-tileSize*(i-((size-1)*3)));
        }
        return g;
    }
    public int getTile(int i){
        return t.get(i);
    }
    private static int randomInt(int from, int to){
        return (int)Math.floor((Math.random()*(to-from+1))+from);
    }
}
