import acm.graphics.GPoint;
import acm.program.GraphicsProgram;
import svu.csc213.Dialog;

import java.awt.*;
import java.util.ArrayList;

public class BoardGame extends GraphicsProgram {

    @Override
    public void run(){
        waitForClick();
        int turns = Dialog.getInteger("Would you like short(1), medium(2), or long(3)");
        GBoard g;
        if(turns == 1){
            turns = 25;
            g = new GBoard(8,100);
        }
        else if (turns == 2){
            turns = 25;
            g = new GBoard(11,75);
        }
        else{
            turns = 50;
            g = new GBoard(15,50);
        }
        add(g,getWidth()/2-g.getWidth()/2,getHeight()/2-g.getHeight()/2);
        Dialog.showMessage("Welcome to board game.");
        Dialog.showMessage("Every turn you will roll dice.");
        Dialog.showMessage("You will be able to roll one die or two dice.");
        Dialog.showMessage("It will cost you 1 gold to roll two dice.");
        Dialog.showMessage("You can get gold by landing on gold tiles and going around the board.");
        Dialog.showMessage("You will start with ten gold.");
        Dialog.showMessage("The first player to "+turns+" gold wins.");
        int players = Dialog.getInteger("How many players would you like to play with?");
        ArrayList<GPlayer> l = new ArrayList<>();
        for (int i = 1; i <= players; i++) {
            GPlayer p = new GPlayer(Dialog.getString("What is the name of the " + i +"th player?"),StringToColor(Dialog.getString("What color would they like?")),g);
            l.add(p);
        }
        int winner = -1;
        while(true){
            for (int i = 0; i < l.size(); i++) {
                if(l.get(i).skipped){
                    Dialog.showMessage(l.get(i).name + " was skipped.");
                    l.get(i).skipped = false;
                }
                else{
                    Dialog.showMessage("it is "+l.get(i).name + "'s turn.");
                    doTurn(g,l.get(i));
                }
                if(l.get(i).g >= turns){
                    winner = i;
                    break;
                }
            }
            if (winner!=-1){
                Dialog.showMessage(l.get(winner).name+" wins!");
                break;
            }
        }
        exit();
    }
    private Color StringToColor(String s){
        if (s.equalsIgnoreCase("red")){
            return Color.red;
        }
        else if (s.equalsIgnoreCase("orange")){
            return Color.orange;
        }
        else if (s.equalsIgnoreCase("yellow")){
            return Color.yellow;
        }
        else if (s.equalsIgnoreCase("green")){
            return Color.green;
        }
        else if (s.equalsIgnoreCase("blue")){
            return Color.blue;
        }
        else if (s.equalsIgnoreCase("purple")){
            return new Color(125,0,250);
        }
        else if (s.equalsIgnoreCase("pink")){
            return Color.pink;
        }
        else if (s.equalsIgnoreCase("cyan")){
            return Color.cyan;
        }
        else if (s.equalsIgnoreCase("custom")){
            return new Color (Dialog.getInteger("r?"), Dialog.getInteger("g?"), Dialog.getInteger("b?"));
        }
        return Color.white;
    }
    private void doTurn(GBoard g, GPlayer p){
        addToBoard(g,p);
        int spaces;
        spaces = Dialog.getInteger("Would "+p.name+" like to roll one or two dice?");
        if (spaces == 1){
            Dialog.showMessage("click to roll the die.");
            waitForClick();
            GDice d = new GDice(200);
            add(d,getWidth()/2-d.getWidth()/2,getHeight()/2-d.getHeight()/2);
            spaces = d.rollDice();
            remove(d);
        }
        else if (spaces == 3 &&p.d3){
            p.g-=2;
            p.update(g);
            Dialog.showMessage("click to roll the dice.");
            waitForClick();
            GDice d1 = new GDice(200,Color.black);
            GDice d2 = new GDice(200,p.c);
            GDice d3 = new GDice(200,d2.ccc);
            add(d1,g.getX()+g.getWidth()*0.3-d1.getWidth()/2,g.getY()+g.getHeight()*0.3-d1.getHeight()/2);
            add(d2,g.getX()+g.getWidth()*0.7-d2.getWidth()/2,g.getY()+g.getHeight()*0.3-d1.getHeight()/2);
            add(d3,getWidth()/2-d3.getWidth()/2,g.getY()+g.getHeight()*0.7-d1.getHeight()/2);
            spaces = d1.rollDice() + d2.rollDice() + d3.rollDice();
            remove(d1);
            remove(d2);
            remove(d3);
        }
        else{
            p.g-=1;
            p.update(g);
            Dialog.showMessage("click to roll the dice.");
            waitForClick();
            GDice d1 = new GDice(200,Color.black);
            GDice d2 = new GDice(200,p.c);
            add(d1,g.getX()+g.getWidth()*0.3-d1.getWidth()/2,getHeight()/2-d1.getHeight()/2);
            add(d2,g.getX()+g.getWidth()*0.7-d2.getWidth()/2,getHeight()/2-d2.getHeight()/2);
            spaces = d1.rollDice() + d2.rollDice();
            remove(d1);
            remove(d2);
        }
        movePiece(g,p,spaces);
    }
    private void addToBoard(GBoard b, GPlayer p){
        GPoint g = b.LocatePoint(p.s);
        g.setLocation(g.getX()+getWidth()/2-b.getWidth()/2,g.getY()+getHeight()/2-b.getHeight()/2);
        add(p,g);
    }
    private void movePiece(GBoard b, GPlayer p, int spaces){
        for (int i = 0; i < spaces; i++) {
           pause(500);
           p.s++;
           addToBoard(b,p);
           if((b.size*4)-4==p.s){
               p.s = 0;
               if(b.size == 11){
                   p.g+=10;
                   Dialog.showMessage("you get 10 gold for completing a lap.");
               }
               else if (b.size == 8){
                   p.g+=5;
                   Dialog.showMessage("you get 5 gold for completing a lap.");
               }
               else{
                   p.g+=15;
                   Dialog.showMessage("you get 15 gold for completing a lap.");
               }
               p.update(b);
           }
        }
        doTile(b.getTile(p.s),p,b);
    }
    private void moveBackwards(GBoard b, GPlayer p, int spaces){
        for (int i = 0; i < spaces; i++) {
            pause(500);
            p.s--;
            addToBoard(b,p);
        }
    }
    private void doTile(int i, GPlayer p, GBoard b){
        if(i==2){
            p.skipped = true;
            Dialog.showMessage("your next turn is skipped");
        }
        else if(i==3){
            Dialog.showMessage("roll again!");
            doTurn(b,p);
        }
        else if(i==4){
            Dialog.showMessage("lose 1 gold");
            p.g--;
        }
        else if(i==5){
            Dialog.showMessage("gain 1 gold");
            p.g++;
        }
        else if(i==6){
            Dialog.showMessage("lose 3 gold");
            p.g-=3;
        }
        else if(i==7){
            Dialog.showMessage("gain 3 gold");
            p.g+=3;
        }
        else if(i==8){
            Dialog.showMessage("move backwards 1 space");
            moveBackwards(b,p,1);
        }
        else if(i==9){
            Dialog.showMessage("move forwards 1 space");
            movePiece(b,p,1);
        }
        else if(i==10){
            Dialog.showMessage("move backwards 3 spaces");
            moveBackwards(b,p,3);
        }
        else if(i==11){
            Dialog.showMessage("move forwards 3 spaces");
            movePiece(b,p,3);
        }
        else if(i==12){
            Dialog.showMessage("You can now roll 3 dice for 2 gold");
            p.d3=true;
        }
        else if(i==0){
            Dialog.showMessage("You landed on start. Gain 5 extra gold.");
            p.g+=5;
        }
        p.update(b);
    }
    public static void main(String[] args) {
        new BoardGame().start();
    }
}
