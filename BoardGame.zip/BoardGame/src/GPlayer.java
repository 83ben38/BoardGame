import acm.graphics.GCompound;
import acm.graphics.GLabel;
import acm.graphics.GOval;

import java.awt.*;

public class GPlayer extends GCompound {
    public Color c;
    public int g;
    public int s;
    public String name;
    public boolean skipped = false;
    public boolean d3 = false;
    public GPlayer(String n, Color c, int g, int s, GBoard b){
        name = n;
        this.c=c;
        this.g=g;
        this.s=s;
        update(b);
    }
    public GPlayer(String n, Color c,GBoard g){
        this(n,c,10,0,g);
    }
    public void update(GBoard b){
        removeAll();
        GOval o = new GOval(b.tileSize,b.tileSize);
        o.setFilled(true);
        o.setFillColor(c);
        add(o,0,0);
        GLabel l = new GLabel(g +"");
        add(l,getWidth()/2-l.getWidth()/2,getHeight()/2-l.getHeight()/2);
        GLabel a = new GLabel(name);
        add(a,getWidth()/2-a.getWidth()/2,getHeight()*0.75);
    }
}
